﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;
using System.ComponentModel;

namespace ShoppingCartWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class CartItemsController:ControllerBase
    {
        private readonly IMapper mapper;
        private readonly ICartItemsServices cartItemsServices;

        public CartItemsController(IMapper mapper, ICartItemsServices cartItemsServices)
        {
            this.mapper = mapper;
            this.cartItemsServices = cartItemsServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddCartItemsDto addCartItemsDto)
        {
            //map dto to domain models
            var cartItemsDomainModel = mapper.Map<CartItem>(addCartItemsDto);
            var cartItemsDto = await cartItemsServices.CreateAsync(cartItemsDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<CartItemsDto>(cartItemsDto));
        }

        [HttpGet]
        public async Task<List<CartItemsDto>> GetAll()
        {
            List<CartItem> cartItemsDomainModel = await cartItemsServices.GetAllAsync();

            //map domain models to dto
            return mapper.Map<List<CartItemsDto>>(cartItemsDomainModel);
        }
        [HttpGet]
        [Route("{CartItemId:Guid}")]
        public async Task<IActionResult> Get([FromRoute] Guid CartItemId)
        {
            var cartItemsDomainModel = await cartItemsServices.GetByIdAsync(CartItemId);
            if (cartItemsDomainModel == null)
            {
                return NotFound();
            }
            var cartItemsDto = mapper.Map<CartItemsDto>(cartItemsDomainModel);
            return Ok(cartItemsDto);
        }
        [HttpPut]
        [Route("{CartItemId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid CartItemId, [FromBody] UpdateCartItemsDto updateCartItemsDto)
        {
            var cartItemsDomainModel = mapper.Map<CartItem>(updateCartItemsDto);

            cartItemsDomainModel = await cartItemsServices.UpdateAsync(CartItemId, cartItemsDomainModel);

            if (cartItemsDomainModel == null)
            {
                return NotFound();
            }
            var cartItemsDto = mapper.Map<CartItemsDto>(cartItemsDomainModel);
            return Ok(cartItemsDto);
        }

        [HttpDelete]
        [Route("{CartItemId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid CartItemId)
        {
            var cartItemsDomainModel = await cartItemsServices.DeleteAsync(CartItemId);
            if (cartItemsDomainModel == null)
            {
                return NotFound();
            }
            var cartItemsDto = mapper.Map<CartItemsDto>(cartItemsDomainModel);

            return Ok(cartItemsDto);
        }
    }
}

﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{

    //url-api/controllers
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly IMapper mapper;
        private readonly ICategoryServices categoryServices;

        public CategoriesController(IMapper mapper, ICategoryServices categoryServices)
        {
            this.mapper = mapper;
            this.categoryServices = categoryServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddCategoryDto addCategoryDto)
        {
            //map dto to domain models
            var categoryDomainModel = mapper.Map<Category>(addCategoryDto);
            var categoryDto = await categoryServices.CreateAsync(categoryDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<CategoriesDto>(categoryDto));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var categoryDomainModel = await categoryServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<CategoriesDto>>(categoryDomainModel));
        }
        [HttpGet]
        [Route("{CategoryId:Guid}")]
        public async Task<IActionResult> Get([FromRoute]Guid CategoryId)
        {
            var categoryDomainModel = await categoryServices.GetByIdAsync(CategoryId);
            if (categoryDomainModel == null)
            {
                return NotFound();
            }
            var categoryDto = mapper.Map<CategoriesDto>(categoryDomainModel);
            return Ok(categoryDto);
        }
        [HttpPut]
        [Route("{CategoryId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid CategoryId, [FromBody] UpdateCategoryDto updateCategoryDto)
        {
            var categoryDomainModel = mapper.Map<Category>(updateCategoryDto);

            categoryDomainModel = await categoryServices.UpdateAsync(CategoryId, categoryDomainModel);

            if (categoryDomainModel == null)
            {
                return NotFound();
            }
            var categoryDto = mapper.Map<CategoriesDto>(categoryDomainModel);
            return Ok(categoryDto);
        }

        [HttpDelete]
        [Route("{CategoryId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid CategoryId)
        {
            var categoryDomainModel = await categoryServices.DeleteAsync(CategoryId);
            if (categoryDomainModel == null)
            {
                return NotFound();
            }
            var categoryDto = mapper.Map<CategoriesDto>(categoryDomainModel);

            return Ok(categoryDto);
        }

    }
}

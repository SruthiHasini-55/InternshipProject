﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderedItemController:ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IOrderedItemsServices orderedItemsServices;

        public OrderedItemController(IMapper mapper, IOrderedItemsServices orderedItemsServices)
        {
            this.mapper = mapper;
            this.orderedItemsServices = orderedItemsServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddOrderedItemsDto addOrderedItemsDto)
        {
            //map dto to domain models
            var orderedItemsDomainModel = mapper.Map<OrderedItem>(addOrderedItemsDto);
            var orderedItemsDto = await orderedItemsServices.CreateAsync(orderedItemsDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<OrderedItemsDto>(orderedItemsDto));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orderedItemsDomainModel = await orderedItemsServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<OrderedItemsDto>>(orderedItemsDomainModel));
        }
        [HttpGet]
        [Route("{OrderItemId:Guid}")]
        public async Task<IActionResult> Get([FromRoute] Guid OrderItemId)
        {
            var orderedItemsDomainModel = await orderedItemsServices.GetByIdAsync(OrderItemId);
            if (orderedItemsDomainModel == null)
            {
                return NotFound();
            }
            var orderedItemsDto = mapper.Map<OrderedItemsDto>(orderedItemsDomainModel);
            return Ok(orderedItemsDto);
        }
        [HttpPut]
        [Route("{OrderItemId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid OrderItemId, [FromBody] UpdateOrderedItemsDto updateOrderedItemsDto)
        {
            var orderedItemsDomainModel = mapper.Map<OrderedItem>(updateOrderedItemsDto);

            orderedItemsDomainModel = await orderedItemsServices.UpdateAsync(OrderItemId, orderedItemsDomainModel);

            if (orderedItemsDomainModel == null)
            {
                return NotFound();
            }
            var orderedItemsDto = mapper.Map<OrderedItemsDto>(orderedItemsDomainModel);
            return Ok(orderedItemsDto);
        }

        [HttpDelete]
        [Route("{OrderItemId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid OrderItemId)
        {
            var orderedItemsDomainModel = await orderedItemsServices.DeleteAsync(OrderItemId);
            if (orderedItemsDomainModel == null)
            {
                return NotFound();
            }
            var orderedItemsDto = mapper.Map<OrderedItemsDto>(orderedItemsDomainModel);

            return Ok(orderedItemsDto);
        }
    }
}

﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : Controller
    {
        private readonly IMapper mapper;
        private readonly IOrderServices orderServices;

        public OrdersController(IMapper mapper, IOrderServices orderServices)
        {
            this.mapper = mapper;
            this.orderServices = orderServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddOrdersDto addOrdersDto)
        {
            //map dto to domain modelsaddOrdersDto
            var orderDomainModel = mapper.Map<Order>(addOrdersDto);
            var orderDto = await orderServices.CreateAsync(orderDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<OrdersDto>(orderDto));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orderDomainModel = await orderServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<OrdersDto>>(orderDomainModel));
        }
        [HttpGet]
        [Route("{OrderId:Guid}")]
        public async Task<IActionResult> Get([FromRoute] Guid OrderId)
        {
            var orderDomainModel = await orderServices.GetByIdAsync(OrderId);
            if (orderDomainModel == null)
            {
                return NotFound();
            }
            var orderDto = mapper.Map<OrdersDto>(orderDomainModel);
            return Ok(orderDto);
        }
        [HttpPut]
        [Route("{OrderId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid OrderId, [FromBody] UpdateOrdersDto updateOrdersDto)
        {
            var orderDomainModel = mapper.Map<Order>(updateOrdersDto);

            orderDomainModel = await orderServices.UpdateAsync(OrderId, orderDomainModel);

            if (orderDomainModel == null)
            {
                return NotFound();
            }
            var orderDto = mapper.Map<OrdersDto>(orderDomainModel);
            return Ok(orderDto);
        }

        [HttpDelete]
        [Route("{OrderId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid OrderId)
        {
            var orderDomainModel = await orderServices.DeleteAsync(OrderId);
            if (orderDomainModel == null)
            {
                return NotFound();
            }
            var orderDto = mapper.Map<OrdersDto>(orderDomainModel);

            return Ok(orderDto);
        }
    }
}

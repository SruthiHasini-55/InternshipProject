﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IPaymentServices paymentServices;

        public PaymentsController(IMapper mapper, IPaymentServices paymentServices)
        {
            this.mapper = mapper;
            this.paymentServices = paymentServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddPaymentDto addPaymentDto)
        {
            //map dto to domain models
            var paymentDomainModel = mapper.Map<Payment>(addPaymentDto);
            var paymentDto = await paymentServices.CreateAsync(paymentDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<PaymentsDto>(paymentDto));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var paymentDomainModel = await paymentServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<PaymentsDto>>(paymentDomainModel));
        }
        [HttpGet]
        [Route("{PaymentId:Guid}")]
        public async Task<IActionResult> Get([FromRoute] Guid PaymentId)
        {
            var paymentDomainModel = await paymentServices.GetByIdAsync(PaymentId);
            if (paymentDomainModel == null)
            {
                return NotFound();
            }
            var paymentDto = mapper.Map<PaymentsDto>(paymentDomainModel);
            return Ok(paymentDto);
        }

    }
}

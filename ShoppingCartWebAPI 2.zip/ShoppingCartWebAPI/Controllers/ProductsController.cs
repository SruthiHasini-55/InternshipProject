﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IProductsServices productsServices;

        public ProductsController(IMapper mapper, IProductsServices productsServices)
        {
            this.mapper = mapper;
            this.productsServices = productsServices;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddProductsDto addProductsDto)
        {
            //map dto to domain models
            var productDomainModel = mapper.Map<Product>(addProductsDto);
            var productDto = await productsServices.CreateAsync(productDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<ProductsDto>(productDto));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var productDomainModel = await productsServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<ProductsDto>>(productDomainModel));
        }
        [HttpGet]
        [Route("{ProductId:Guid}")]
        public async Task<IActionResult> Get([FromRoute] Guid ProductId)
        {
            var productDomainModel = await productsServices.GetByIdAsync(ProductId);
            if (productDomainModel == null)
            {
                return NotFound();
            }
            var productsDto = mapper.Map<ProductsDto>(productDomainModel);
            return Ok(productsDto);
        }
        [HttpPut]
        [Route("{ProductId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid ProductId, [FromBody] UpdateProductsDto updateProductsDto)
        {
            var productDomainModel = mapper.Map<Product>(updateProductsDto);

            productDomainModel = await productsServices.UpdateAsync(ProductId, productDomainModel);

            if (productDomainModel == null)
            {
                return NotFound();
            }
            var productsDto = mapper.Map<ProductsDto>(productDomainModel);
            return Ok(productsDto);
        }

        [HttpDelete]
        [Route("{ProductId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid ProductId)
        {
            var productDomainModel = await productsServices.DeleteAsync(ProductId);
            if (productDomainModel == null)
            {
                return NotFound();
            }
            var productsDto = mapper.Map<ProductsDto>(productDomainModel);

            return Ok(productsDto);
        }
    }
}

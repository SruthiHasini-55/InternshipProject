using AutoMapper;
using l.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Repositories;



namespace ShoppingCartWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class RolesController : ControllerBase
    {

        private readonly IRolesServices rolesRepository;
        private readonly IMapper mapper;

        public RolesController(IRolesServices rolesRepository,IMapper mapper)
        {
            this.rolesRepository = rolesRepository;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var rolesDomains = await rolesRepository.GetAllAsync();
            //mapping domain models to DTOs using AutoMapper
            var rolesDto=mapper.Map<List<RolesDto>>(rolesDomains);

            return Ok(rolesDto);
        }
        

        [HttpGet]
        [Route("{RoleId:Guid}")]
        public async Task<IActionResult> GetById([FromRoute] Guid RoleId)
        {
            var rolesDomains = await rolesRepository.GetByIdAsync(RoleId);
            if (rolesDomains == null)
            {
                return NotFound();
            }
            //mapping domain models to DTOs using AutoMapper
            var rolesDto = mapper.Map<RolesDto>(rolesDomains);
            return Ok(rolesDto);
        }


        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddRoleRequestDto addRoleRequestDto)
        {
            var rolesDomain = mapper.Map<Role>(addRoleRequestDto);
            rolesDomain=await rolesRepository.CreateAsync(rolesDomain);
            var rolesDto = mapper.Map<RolesDto>(rolesDomain);
            //return CreatedAtAction(nameof(GetById), new { RoleId = Guid.NewGuid() }, rolesDto);
            return Ok(rolesDto);
        }

        [HttpPut]
        [Route("{RoleId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid RoleId, [FromBody] UpdateRoleRequestDto updateRoleRequestDto)
        {
            var rolesDomain = mapper.Map<Role>(updateRoleRequestDto);
            rolesDomain = await rolesRepository.UpdateAsync(RoleId, rolesDomain);
            if (rolesDomain == null) 
            { 
                return NotFound();
            }
            //convert domain model to dto using automapper
            var rolesDto=mapper.Map<RolesDto>(rolesDomain);
            return Ok(rolesDto);
        }

        [HttpDelete]
        [Route("{RoleId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid RoleId) 
        {
            var rolesDomain = await rolesRepository.DeleteAsync(RoleId);
            if (rolesDomain == null) 
            {
                return  NotFound();
            }
            //convert domain model to dto using automapper
            var rolesDto = mapper.Map<RolesDto>(rolesDomain);

            return Ok(rolesDto);
        }
    }
}

﻿using AutoMapper;
using l.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;
using ShoppingCartWebAPI.Services;

namespace ShoppingCartWebAPI.Controllers
{
    [Authorize]
    //url-api/users
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ECommerceDbContext _context;
        private readonly IMapper mapper;
        private readonly IUserServices userServices;

        public UsersController(IMapper mapper, IUserServices userServices)
        {
            this.mapper = mapper;
            this.userServices = userServices;
            this._context = _context;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AddUserRequestDto addUserRequestDto)
        {
            //map dto to domain models
            var userDomainModel = mapper.Map<User>(addUserRequestDto);
            var returnValue = await userServices.CreateAsync(userDomainModel);
            //map domain model to dto
            return Ok(mapper.Map<UserDto>(returnValue));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var userDomainModel = await userServices.GetAllAsync();

            //map domain models to dto
            return Ok(mapper.Map<List<UserDto>>(userDomainModel));
        }
        //[HttpGet("GetUser")]
        //public async Task<ActionResult<User>> GetUser()
        //{
        //    string email = HttpContext.User.Identity.Name;
        //    var user = await _context.Users.Where(user => user.Email==email).FirstOrDefaultAsync();
        //    user.Password = null;
            
        //    return user;
        //}
        [HttpGet]
        [Route("{UserId:Guid}")]
        public async Task<IActionResult> Get([FromRoute]Guid UserId)
        {
            var userDomainModel = await userServices.GetByIdAsync(UserId);
            if (userDomainModel == null)
            {
                return NotFound();
            }
            var usersDto = mapper.Map<UserDto>(userDomainModel);
            return Ok(usersDto);
        }
        [HttpPut]
        [Route("{UserId:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid UserId, [FromBody] UpdateUserRequestDto updateUserRequestDto)
        {
            var userDomainModel = mapper.Map<User>(updateUserRequestDto);

            userDomainModel = await userServices.UpdateAsync(UserId, userDomainModel);

            if (userDomainModel == null)
            {
                return NotFound();
            }
            var usersDto = mapper.Map<UserDto>(userDomainModel);
            return Ok(usersDto);
        }

        [HttpDelete]
        [Route("{UserId:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid UserId)
        {
            var userDomainModel = await userServices.DeleteAsync(UserId);
            if (userDomainModel == null)
            {
                return NotFound();
            }
            var usersDto = mapper.Map<UserDto>(userDomainModel);

            return Ok(usersDto);
        }

    }
}

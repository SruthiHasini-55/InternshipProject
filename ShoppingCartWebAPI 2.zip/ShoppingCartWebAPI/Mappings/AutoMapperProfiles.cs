﻿using AutoMapper;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Models.DTO;

namespace ShoppingCartWebAPI.Mappings
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles() 
        {
            CreateMap<Role,RolesDto>().ReverseMap();
            CreateMap<Role, AddRoleRequestDto>().ReverseMap();
            CreateMap<Role, UpdateRoleRequestDto>().ReverseMap();

            CreateMap<User, AddUserRequestDto>().ReverseMap();   
            CreateMap<User, UserDto>().ReverseMap();
            CreateMap<User, UpdateUserRequestDto>().ReverseMap();

            CreateMap<Category, CategoriesDto>().ReverseMap();
            CreateMap<Category, AddCategoryDto>().ReverseMap();
            CreateMap<Category, UpdateCategoryDto>().ReverseMap();

            CreateMap<Product, ProductsDto>().ReverseMap();
            CreateMap<Product, AddProductsDto>().ReverseMap();
            CreateMap<Product, UpdateProductsDto>().ReverseMap();

            CreateMap<CartItem, CartItemsDto>().ReverseMap();
            CreateMap<CartItem, AddCartItemsDto>().ReverseMap();
            CreateMap<CartItem, UpdateCartItemsDto>().ReverseMap();

            CreateMap<Payment, PaymentsDto>().ReverseMap();
            CreateMap<Payment, AddPaymentDto>().ReverseMap();

            CreateMap<Order, OrdersDto>().ReverseMap();
            CreateMap<Order, AddOrdersDto>().ReverseMap();
            CreateMap<Order, UpdateOrdersDto>().ReverseMap();

            CreateMap<OrderedItem, OrderedItemsDto>().ReverseMap();
            CreateMap<OrderedItem, AddOrderedItemsDto>().ReverseMap();
            CreateMap<OrderedItem, UpdateOrderedItemsDto>().ReverseMap();
        }
    }
}

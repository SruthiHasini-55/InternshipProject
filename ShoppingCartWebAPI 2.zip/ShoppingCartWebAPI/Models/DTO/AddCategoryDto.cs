﻿using System;
using System.Collections.Generic;

namespace ShoppingCartWebAPI.Models.DTO;

public partial class AddCategoryDto
{
    public string? Name { get; set; }

    public string? Description { get; set; }

    public Guid? CreatedBy { get; set; }

}

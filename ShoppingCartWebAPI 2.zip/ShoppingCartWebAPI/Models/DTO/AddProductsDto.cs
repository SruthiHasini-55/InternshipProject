﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Models.DTO
{
    public class AddProductsDto
    {

        public string Name { get; set; } = null!;

        public string? Description { get; set; }

        public decimal Price { get; set; }

        public int QuantityAvailable { get; set; }

        public Guid? CategoryId { get; set; }

        public bool IsAvailable { get; set; }

        public Guid? CreatedBy { get; set; }

        //public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();

        //public virtual Category? Category { get; set; }

        //public virtual ICollection<OrderedItem> OrderedItems { get; set; } = new List<OrderedItem>();
    }
}

﻿namespace ShoppingCartWebAPI.Models.DTO
{
    public class AddRoleRequestDto
    {
        public string RoleName { get; set; }
    }
}

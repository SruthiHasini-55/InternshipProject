﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Models.DTO
{
    public class PaymentsDto
    {
        public Guid PaymentId { get; set; }

        public string PaymentMethod { get; set; } = null!;

        public decimal Amount { get; set; }

        public string TransactionId { get; set; } = null!;

        //public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}

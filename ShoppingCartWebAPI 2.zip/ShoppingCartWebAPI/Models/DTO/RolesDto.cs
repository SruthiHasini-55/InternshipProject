﻿using System.Text.Json.Serialization;

namespace ShoppingCartWebAPI.Models.DTO
{
    public class RolesDto
    {
        public Guid RoleId { get; set; }
        public string RoleName { get; set; } 
    }
}

﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Models.DTO
{
    public class UpdateOrdersDto
    {

        public Guid? UserId { get; set; }

        public DateTime OrderDate { get; set; }

        public decimal TotalAmount { get; set; }

        public string Status { get; set; } = null!;

        public Guid? UpdatedBy { get; set; }

        public Guid? PaymentId { get; set; }

        public virtual ICollection<OrderedItem> OrderedItems { get; set; } = new List<OrderedItem>();

        public virtual Payment? Payment { get; set; }

        public virtual User? UpdatedByNavigation { get; set; }

        public virtual User? User { get; set; }
    }
}

﻿namespace ShoppingCartWebAPI.Models.DTO
{
    public class UpdateRoleRequestDto
    {
        public string RoleName { get; set; }
    }
}

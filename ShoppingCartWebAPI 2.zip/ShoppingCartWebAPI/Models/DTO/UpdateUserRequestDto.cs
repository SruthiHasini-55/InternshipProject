﻿namespace ShoppingCartWebAPI.Models.DTO
{
    public class UpdateUserRequestDto
    {
        public string UserName { get; set; } = null!;

        public string Password { get; set; } = null!;

        public string Email { get; set; } = null!;

        public string? Address { get; set; }

        public string PhoneNumber { get; set; } = null!;

        public Guid? UpdatedBy { get; set; }

        public Guid? RoleId { get; set; }
    }

}

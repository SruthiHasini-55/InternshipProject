﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Models.DTO
{
    public class UserDto
    {
        public Guid UserId { get; set; }

        public string UserName { get; set; } = null!;

        public string Password { get; set; } = null!;

        public string Email { get; set; } = null!;

        public string? Address { get; set; }

        public string PhoneNumber { get; set; } = null!;

        public DateTime CreatedOn { get; set; }

        public DateTime UpdatedOn { get; set; }

        public Guid? UpdatedBy { get; set; }

        public Guid? CreatedBy { get; set; }

        public virtual RolesDto? Role { get; set; }
    }

}

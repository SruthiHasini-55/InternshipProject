﻿using System;
using System.Collections.Generic;

namespace ShoppingCartWebAPI.Models.Domain;

public partial class Payment
{
    public Guid PaymentId { get; set; }

    public string PaymentMethod { get; set; } = null!;

    public decimal Amount { get; set; }

    public string TransactionId { get; set; } = null!;

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}

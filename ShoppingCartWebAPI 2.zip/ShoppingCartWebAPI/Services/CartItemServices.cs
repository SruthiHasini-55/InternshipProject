﻿using l.Models;
using Microsoft.EntityFrameworkCore;
using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public class CartItemServices:ICartItemsServices
    {
        private readonly ECommerceDbContext _context;

        public CartItemServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<CartItem> CreateAsync(CartItem cartItem)
        {
            cartItem.CartItemId = Guid.NewGuid();
            cartItem.CreatedOn = DateTime.Now;
            cartItem.UpdatedOn = DateTime.Now;
            await _context.CartItems.AddAsync(cartItem);
            await _context.SaveChangesAsync();
            return cartItem;
        }

        public async Task<CartItem?> DeleteAsync(Guid CartItemId)
        {
            var existingCartItem = await _context.CartItems.FirstOrDefaultAsync(x => x.CartItemId == CartItemId);
            if (existingCartItem == null)
            {
                return null;
            }
            _context.CartItems.Remove(existingCartItem);
            await _context.SaveChangesAsync();
            return existingCartItem;
        }

        public Task<List<CartItem>> GetAllAsync()
        {
            return _context.CartItems
                .Include(p => p.Product)
                .Include(u => u.User)
                .ToListAsync();
        }

        public async Task<CartItem?> GetByIdAsync(Guid CartItemId)
        {
            return await _context.CartItems
                .Include(p => p.Product)
                .Include(u => u.User)
                .FirstOrDefaultAsync(x => x.CartItemId == CartItemId);
        }

        public async Task<CartItem?> UpdateAsync(Guid CartItemId, CartItem cartItem)
        {
            var existingCartItem = await _context.CartItems.FirstOrDefaultAsync(x => x.CartItemId == CartItemId);
            if (existingCartItem == null)
            {
                return null;
            }

            existingCartItem.UserId = cartItem.UserId;
            existingCartItem.ProductId = cartItem.ProductId;
            existingCartItem.Quantity = cartItem.Quantity;
            existingCartItem.Price = cartItem.Price;

            await _context.SaveChangesAsync();
            return existingCartItem;
        }
    }
}

﻿using l.Models;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ShoppingCartWebAPI.Services
{
    public class CategoryServices:ICategoryServices
    {

        private readonly ECommerceDbContext _context;

        public CategoryServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<Category> CreateAsync(Category categories)
        {
            categories.CategoryId = Guid.NewGuid();
            categories.CreatedOn = DateTime.Now;
            categories.UpdatedOn = DateTime.Now;
            await _context.Categories.AddAsync(categories);
            await _context.SaveChangesAsync();
            return categories;
        }

        public async Task<Category?> DeleteAsync(Guid CategoryId)
        {
            var existingCategory = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryId == CategoryId);
            if (existingCategory == null)
            {
                return null;
            }
            _context.Categories.Remove(existingCategory);
            await _context.SaveChangesAsync();
            return existingCategory;
        }

        public Task<List<Category>> GetAllAsync()
        {
            return _context.Categories.ToListAsync();
        }

        public async Task<Category?> GetByIdAsync(Guid CategoryId)
        {
            return await _context.Categories.FirstOrDefaultAsync(x => x.CategoryId == CategoryId);
        }

        public Task<Category?> GetByIdAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<Category?> UpdateAsync(Guid CategoryId, Category categories)
        {
            var existingCategory = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryId == CategoryId);
            if (existingCategory == null)
            {
                return null;
            }

            existingCategory.Name = categories.Name;
            existingCategory.Description = categories.Description;
            existingCategory.UpdatedBy = categories.UpdatedBy;

            await _context.SaveChangesAsync();
            return existingCategory;
        }

        
    }
}



﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface ICartItemsServices
    {
        Task<CartItem> CreateAsync(CartItem cartItem);
        Task<List<CartItem>> GetAllAsync();
        Task<CartItem> GetByIdAsync(Guid CartItemId);
        Task<CartItem?> UpdateAsync(Guid CartItemId, CartItem cartItem);
        Task<CartItem?> DeleteAsync(Guid CartItemId);
    }
}

﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface ICategoryServices
    {
        Task<List<Category>> GetAllAsync();
        Task<Category?> GetByIdAsync();
        Task<Category?> GetByIdAsync(Guid CategoryId);
        Task<Category> CreateAsync(Category Categories);
        Task<Category?> UpdateAsync(Guid CategoryId, Category categories);
        Task<Category?> DeleteAsync(Guid CategoryId);
    }
}

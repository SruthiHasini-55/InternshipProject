﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface IOrderServices
    {
        Task<Order> CreateAsync(Order order);
        Task<List<Order>> GetAllAsync();
        Task<Order> GetByIdAsync(Guid OrderId);
        Task<Order?> UpdateAsync(Guid OrderId, Order order);
        Task<Order?> DeleteAsync(Guid OrderId);
    }
}

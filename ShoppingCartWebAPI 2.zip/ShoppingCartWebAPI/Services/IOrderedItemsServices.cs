﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface IOrderedItemsServices
    {
        Task<OrderedItem> CreateAsync(OrderedItem orderedItem);
        Task<List<OrderedItem>> GetAllAsync();
        Task<OrderedItem> GetByIdAsync(Guid OrderItemId);
        Task<OrderedItem?> UpdateAsync(Guid OrderItemId, OrderedItem orderedItem);
        Task<OrderedItem?> DeleteAsync(Guid OrderItemId);
    }

}

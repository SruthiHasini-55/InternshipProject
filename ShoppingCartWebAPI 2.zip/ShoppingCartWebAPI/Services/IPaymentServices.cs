﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface IPaymentServices
    {
        Task<Payment>CreateAsync(Payment payment);
        Task<List<Payment>>GetAllAsync();
        Task<Payment> GetByIdAsync(Guid PaymentId);
        Task<Payment?> UpdateAsync(Guid PaymentId, Payment payment);
        Task<Payment?> DeleteAsync(Guid PaymentId);
    }
}

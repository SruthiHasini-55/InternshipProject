﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface IProductsServices
    {
        Task<Product> CreateAsync(Product product);
        Task<List<Product>> GetAllAsync();
        Task<Product> GetByIdAsync(Guid ProductId);
        Task<Product?> UpdateAsync(Guid ProductId, Product product);
        Task<Product?> DeleteAsync(Guid ProductId);
    }
}

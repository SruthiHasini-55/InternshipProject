﻿using ShoppingCartWebAPI.Models.Domain;
namespace ShoppingCartWebAPI.Repositories
{
    public interface IRolesServices
    {
        Task<List<Role>>GetAllAsync();
        Task<Role?> GetByIdAsync();
        Task<Role?> GetByIdAsync(Guid RoleId);
        Task<Role>CreateAsync(Role roles);  
        Task<Role?> UpdateAsync(Guid RoleId,Role role);
        Task<Role?> DeleteAsync(Guid RoleId);

    }
}

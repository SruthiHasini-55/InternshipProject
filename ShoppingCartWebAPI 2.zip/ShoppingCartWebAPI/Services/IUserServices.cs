﻿using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public interface IUserServices
    {
        Task<User> CreateAsync(User user);
        Task<List<User>> GetAllAsync();
        Task<User> GetByIdAsync(Guid UserId);
        Task<User?> UpdateAsync(Guid UserId, User user);
        Task<User?>DeleteAsync(Guid UserId);
        
    }
}

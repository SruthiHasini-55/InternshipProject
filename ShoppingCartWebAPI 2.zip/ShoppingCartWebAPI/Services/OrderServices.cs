﻿using l.Models;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ShoppingCartWebAPI.Services
{
    public class OrderServices:IOrderServices
    {
        private readonly ECommerceDbContext _context;

        public OrderServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<Order> CreateAsync(Order order)
        {
            order.OrderId = Guid.NewGuid();
            order.CreatedOn = DateTime.Now;
            order.UpdatedOn = DateTime.Now;
            order.OrderDate=DateTime.Now;
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task<Order?> DeleteAsync(Guid OrderId)
        {
            var existingOrder = await _context.Orders.FirstOrDefaultAsync(x => x.OrderId == OrderId);
            if (existingOrder == null)
            {
                return null;
            }
            _context.Orders.Remove(existingOrder);
            await _context.SaveChangesAsync();
            return existingOrder;
        }

        public Task<List<Order>> GetAllAsync()
        {
            return _context.Orders.Include(u => u.User)
                                    .Include(p => p.Payment)
                                    .ToListAsync();
        }

        public async Task<Order?> GetByIdAsync(Guid OrderId)
        {
            return await _context.Orders.Include(u => u.User)
                                    .Include(p => p.Payment)
                                    .FirstOrDefaultAsync(x => x.OrderId == OrderId);
        }

        public async Task<Order?> UpdateAsync(Guid OrderId, Order order)
        {
            var existingOrder = await _context.Orders.FirstOrDefaultAsync(x => x.OrderId == OrderId);
            if (existingOrder == null)
            {
                return null;
            }

            existingOrder.UserId = order.UserId;
            existingOrder.TotalAmount = order.TotalAmount;
            existingOrder.Status = order.Status;
            existingOrder.UpdatedOn = DateTime.Now;
            existingOrder.UpdatedBy = order.UpdatedBy;
            existingOrder.PaymentId = order.PaymentId;

            await _context.SaveChangesAsync();
            return existingOrder;
        }

        
    }
}

﻿using l.Models;
using Microsoft.EntityFrameworkCore;
using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public class OrderedItemsServices:IOrderedItemsServices
    {
        private readonly ECommerceDbContext _context;

        public OrderedItemsServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<OrderedItem> CreateAsync(OrderedItem orderedItem)
        {
            orderedItem.OrderItemId = Guid.NewGuid();
            await _context.OrderedItems.AddAsync(orderedItem);
            await _context.SaveChangesAsync();
            return orderedItem;
        }


        public async Task<OrderedItem?> DeleteAsync(Guid OrderItemId)
        {
            var existingOrderItem = await _context.OrderedItems.FirstOrDefaultAsync(x => x.OrderItemId == OrderItemId);
            if (existingOrderItem == null)
            {
                return null;
            }
            _context.OrderedItems.Remove(existingOrderItem);
            await _context.SaveChangesAsync();
            return existingOrderItem;
        }

        public Task<List<OrderedItem>> GetAllAsync()
        {
            return _context.OrderedItems
                .Include(o => o.Order)
                .Include(p => p.Product)
                .ToListAsync();
        }

        public async Task<OrderedItem?> GetByIdAsync(Guid OrderItemId)
        {
            return await _context.OrderedItems
                .Include(o => o.Order)
                .Include(p => p.Product)
                .FirstOrDefaultAsync(x => x.OrderItemId == OrderItemId);
        }

        public async Task<OrderedItem?> UpdateAsync(Guid OrderItemId, OrderedItem orderedItem)
        {
            var existingOrderItem = await _context.OrderedItems.FirstOrDefaultAsync(x => x.OrderItemId == OrderItemId);
            if (existingOrderItem == null)
            {
                return null;
            }

            existingOrderItem.OrderId = orderedItem.OrderId;
            existingOrderItem.ProductId = orderedItem.ProductId;
            existingOrderItem.Quantity = orderedItem.Quantity;
            existingOrderItem.UnitPrice = orderedItem.UnitPrice;

            await _context.SaveChangesAsync();
            return existingOrderItem;
        }
    }
}

﻿using l.Models;
using Microsoft.EntityFrameworkCore;
using ShoppingCartWebAPI.Models.Domain;

namespace ShoppingCartWebAPI.Services
{
    public class PaymentServices:IPaymentServices
    {
        private readonly ECommerceDbContext _context;

        public PaymentServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<Payment> CreateAsync(Payment payment)
        {
            payment.PaymentId = Guid.NewGuid();
            await _context.Payments.AddAsync(payment);
            await _context.SaveChangesAsync();
            return payment;
        }

        public async Task<Payment?> DeleteAsync(Guid PaymentId)
        {
            var existingPayment = await _context.Payments.FirstOrDefaultAsync(x => x.PaymentId == PaymentId);
            if (existingPayment == null)
            {
                return null;
            }
            _context.Payments.Remove(existingPayment);
            await _context.SaveChangesAsync();
            return existingPayment;
        }

        public Task<List<Payment>> GetAllAsync()
        {
            return _context.Payments.ToListAsync();
        }

        public async Task<Payment?> GetByIdAsync(Guid PaymentId)
        {
            return await _context.Payments.FirstOrDefaultAsync(x => x.PaymentId == PaymentId);
        }

        public Task<Payment?> GetByIdAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<Payment?> UpdateAsync(Guid PaymentId, Payment payment)
        {
            var existingPayment = await _context.Payments.FirstOrDefaultAsync(x => x.PaymentId == PaymentId);
            if (existingPayment == null)
            {
                return null;
            }

            existingPayment.PaymentMethod = payment.PaymentMethod;
            existingPayment.Amount = payment.Amount;
            existingPayment.TransactionId = payment.TransactionId;

            await _context.SaveChangesAsync();
            return existingPayment;
        }
    }
}

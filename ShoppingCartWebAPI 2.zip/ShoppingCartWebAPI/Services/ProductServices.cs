﻿using l.Models;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ShoppingCartWebAPI.Services
{
    public class ProductServices : IProductsServices
    {
        private readonly ECommerceDbContext _context;

        public ProductServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<Product> CreateAsync(Product product)
        {
            product.ProductId = Guid.NewGuid();
            product.CreatedOn = DateTime.Now;
            product.UpdatedOn = DateTime.Now;
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            return product;
        }

        public async Task<Product?> DeleteAsync(Guid ProductId)
        {
            var existingProduct = await _context.Products.FirstOrDefaultAsync(x => x.ProductId == ProductId);
            if (existingProduct == null)
            {
                return null;
            }
            _context.Products.Remove(existingProduct);
            await _context.SaveChangesAsync();
            return existingProduct;
        }

        public Task<List<Product>> GetAllAsync()
        {
            return _context.Products.Include(u => u.Category).ToListAsync();
        }

        public async Task<Product?> GetByIdAsync(Guid ProductId)
        {
            return await _context.Products.Include(u => u.Category).FirstOrDefaultAsync(x => x.ProductId == ProductId);
        }

        public async Task<Product?> UpdateAsync(Guid ProductId, Product product)
        {
            var existingProduct = await _context.Products.FirstOrDefaultAsync(x => x.ProductId == ProductId);
            if (existingProduct == null)
            {
                return null;
            }

            existingProduct.Name = product.Name;
            existingProduct.Description = product.Description;
            existingProduct.Price = product.Price;
            existingProduct.QuantityAvailable = product.QuantityAvailable;
            existingProduct.IsAvailable = product.IsAvailable;
            existingProduct.UpdatedOn = DateTime.Now;
            existingProduct.UpdatedBy = product.UpdatedBy;
            existingProduct.CategoryId = product.CategoryId;

            await _context.SaveChangesAsync();
            return existingProduct;
        }
    }
}

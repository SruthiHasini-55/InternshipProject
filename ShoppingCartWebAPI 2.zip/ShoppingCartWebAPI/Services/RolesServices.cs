﻿using l.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using ShoppingCartWebAPI.Models.Domain;


namespace ShoppingCartWebAPI.Repositories
{
    public class RolesServices : IRolesServices
    {
        private readonly ECommerceDbContext _context;

        public RolesServices(ECommerceDbContext dbcontext)
        {
            this._context = dbcontext;
        }
        public async Task<List<Role>> GetAllAsync()
        {
            return await _context.Roles.ToListAsync();
        }

        public async Task<Role?> GetByIdAsync(Guid RoleId)
        {
            return await _context.Roles.FirstOrDefaultAsync(x=>x.RoleId == RoleId);
        }
        public async Task<Role>CreateAsync(Role roles)
        {
            roles.RoleId = Guid.NewGuid();
            await _context.Roles.AddAsync(roles);
            await _context.SaveChangesAsync();
            return roles;
        }


        public async Task<Role?> UpdateAsync(Guid RoleId, Role role)
        {
            var existingRole = await _context.Roles.FirstOrDefaultAsync(x => x.RoleId == RoleId);
            if(existingRole == null) 
            {
                return null;
            }

            existingRole.RoleName = role.RoleName;
            await _context.SaveChangesAsync();
            return existingRole;
        }

        public async Task<Role?> DeleteAsync(Guid RoleId)
        {
            var existingRole= await _context.Roles.FirstOrDefaultAsync(x => x.RoleId == RoleId);
            if( existingRole == null) 
            {
                return null;
            }
            _context.Roles.Remove(existingRole);
            await _context.SaveChangesAsync();
            return existingRole;
        }

        public Task<Role?> GetByIdAsync()
        {
            throw new NotImplementedException();
        }
    }
}

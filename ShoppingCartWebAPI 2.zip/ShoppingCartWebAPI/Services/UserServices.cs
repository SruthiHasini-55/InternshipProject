﻿using l.Models;
using ShoppingCartWebAPI.Models.Domain;
using ShoppingCartWebAPI.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ShoppingCartWebAPI.Services
{
    public class UserServices : IUserServices
    {
        private readonly ECommerceDbContext _context;

        public UserServices(ECommerceDbContext _context)
        {
            this._context = _context;
        }
        public async Task<User> CreateAsync(User user)
        {
            user.UserId = Guid.NewGuid();
            user.CreatedOn = DateTime.Now;
            user.UpdatedOn = DateTime.Now;  
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<User?> DeleteAsync(Guid UserId)
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(x => x.UserId == UserId);
            if (existingUser == null)
            {
                return null;
            }
            _context.Users.Remove(existingUser);
            await _context.SaveChangesAsync();
            return existingUser;
        }

        public Task<List<User>> GetAllAsync()
        {
            return _context.Users.Include(u => u.Role).ToListAsync();
        }

        public async Task<User?> GetByIdAsync(Guid UserId)
        {
            return await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(x=>x.UserId==UserId);
        }

        public async Task<User?> UpdateAsync(Guid UserId, User user)
        {
            var existingUser = await _context.Users.FirstOrDefaultAsync(x => x.UserId == UserId);
            if (existingUser == null)
            {
                return null;
            }

            existingUser.UserName = user.UserName;
            existingUser.Password = user.Password;
            existingUser.Email = user.Email;
            existingUser.Address = user.Address;
            existingUser.PhoneNumber = user.PhoneNumber;
            existingUser.UpdatedOn = DateTime.Now;
            existingUser.UpdatedBy = user.UpdatedBy;
            existingUser.RoleId = user.RoleId;

            await _context.SaveChangesAsync();
            return existingUser;
        }
    }
}
